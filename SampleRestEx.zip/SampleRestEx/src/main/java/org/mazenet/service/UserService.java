package org.mazenet.service;

import org.mazenet.entities.User;

public interface UserService {
	public boolean register(User user);
	public String checkWhetherUserIsExisted(String email);

}
