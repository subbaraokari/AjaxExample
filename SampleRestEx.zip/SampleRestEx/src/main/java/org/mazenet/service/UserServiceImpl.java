package org.mazenet.service;

import javax.transaction.Transactional;

import org.mazenet.dao.UserDao;
import org.mazenet.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;
	@Override
	public boolean register(User user) {
		return userDao.register(user);
	}

	@Override
	public String checkWhetherUserIsExisted(String email) {
		return userDao.checkWhetherTheUserIsAllreadyExisted(email);
	}

}
