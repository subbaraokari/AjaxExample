package org.mazenet.dao;

import org.mazenet.entities.User;

public interface UserDao {
	
	public User validate(String username,String password);
	public boolean register(User user);
	public String checkWhetherTheUserIsAllreadyExisted(String email);

}
