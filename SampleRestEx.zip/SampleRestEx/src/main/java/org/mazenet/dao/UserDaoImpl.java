package org.mazenet.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.mazenet.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	SessionFactory sessionFactory;

	public User validate(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean register(User user) {
		boolean b=false;
		Session session=sessionFactory.getCurrentSession();
		Integer id=(Integer)session.save(user);
		if(id>=0)
			b=true;
		return b;
	}

	public String checkWhetherTheUserIsAllreadyExisted(String email) {
		String msg="";
		Session session=sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(User.class);
		criteria.add(Restrictions.eq("username", email));
		List<User> users=criteria.list();
		if(!users.isEmpty())
		{
			msg+="User is allready existed";
		}
		return msg;
	}

}
